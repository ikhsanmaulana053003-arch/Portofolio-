FOLDER GAMBAR PORTFOLIO
========================
Masukkan gambar kamu ke folder ini dengan nama:
- profile.jpg       -> foto profil
- marketplace.jpg   -> project optimasi marketplace
- creator.jpg       -> project creator manager
- campaign.jpg      -> project campaign affiliate
- content.jpg       -> project content creator

Ukuran yang disarankan:
- profile.jpg: portrait 4:5
- project images: landscape 16:8 atau 16:9

Setelah gambar dimasukkan, website otomatis menggunakan nama file tersebut.
